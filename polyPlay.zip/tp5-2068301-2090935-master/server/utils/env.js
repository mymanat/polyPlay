const DB_DB = "TP5";
const DB_COLLECTION_SONGS = "songs";
const DB_COLLECTION_PLAYLISTS = "playlists";

// TODO : fournir les bonnes informations de connexion (les <> doivent être enlevés)
const DB_URL = "mongodb+srv://alexandregaudet13:SXJT0h1PHjZjKf8Q@cluster0.xh3okrb.mongodb.net/?retryWrites=true&w=majority";

exports.DB_DB = DB_DB;
exports.DB_COLLECTION_SONGS = DB_COLLECTION_SONGS;
exports.DB_COLLECTION_PLAYLISTS = DB_COLLECTION_PLAYLISTS;
exports.DB_URL = DB_URL;
